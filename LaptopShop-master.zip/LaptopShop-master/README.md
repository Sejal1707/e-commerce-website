# LaptopShop

# LaptopShop
Laptop Shop is web application project. which is based springboot and angular.
Technologies used:
 1. Spring Boot(Backend) 
 2. Angular(Frontend) : version 10.1.4
 3. Node js : version 12.11.1
 4. IDE : Eclipse and VS Code
 5. Database : Mysql 








Modules in project:
1.Admin module
2.User Module
3.Product Module
4.Add to cart Module
5. Payment Module
6. Order details
