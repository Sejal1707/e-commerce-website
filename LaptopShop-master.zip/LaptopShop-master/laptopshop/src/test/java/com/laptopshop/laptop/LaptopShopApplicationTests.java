package com.laptopshop.laptop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaptopShopApplicationTests {

    @Test
    void contextLoads() {
    }

}
